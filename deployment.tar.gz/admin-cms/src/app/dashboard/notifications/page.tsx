import { redirect } from "next/navigation";

export default function NotificationsPage() {
  redirect("/dashboard/notifications/push");
}
