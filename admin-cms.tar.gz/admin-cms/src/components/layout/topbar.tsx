import { Input } from "@/components/ui/input";
import Link from "next/link";

export function Topbar() {
  return (
    <div className="flex h-16 items-center px-8 border-b bg-[#F8F8F8] border-gray-200">
      <div className="flex-1">
        <div className="w-full max-w-sm">
          <Input 
            type="search" 
            placeholder="Search..." 
            className="bg-white border-gray-200"
          />
        </div>
      </div>
      <div className="flex items-center space-x-6 text-sm font-medium text-gray-900">
        <span>Admin Name</span>
        <Link href="#" className="hover:underline">Profile</Link>
      </div>
    </div>
  );
}