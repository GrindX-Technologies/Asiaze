"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import Link from "next/link";

export default function AddNewsPage() {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-black tracking-tight">Manage News</h2>
      
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-black font-bold">Headline</Label>
              <Input 
                placeholder="Enter headline (max 100 chars)" 
                className="bg-white border-gray-200"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Summary</Label>
              <Textarea 
                placeholder="Enter summary (max ~60 words)" 
                className="bg-white border-gray-200 resize-none h-32"
              />
              <div className="text-right text-xs text-gray-500">0/60 words</div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Full Article Link</Label>
              <Input 
                placeholder="Enter full article link" 
                className="bg-white border-gray-200"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Category</Label>
              <Select defaultValue="politics">
                <SelectTrigger className="bg-white border-gray-200">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="politics">Politics</SelectItem>
                  <SelectItem value="entertainment">Entertainment</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Language</Label>
              <Select defaultValue="en">
                <SelectTrigger className="bg-white border-gray-200">
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">EN</SelectItem>
                  <SelectItem value="hin">HIN</SelectItem>
                  <SelectItem value="ben">BEN</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Tags</Label>
              <Input 
                placeholder="Type to add tags" 
                className="bg-white border-gray-200"
              />
            </div>
          </div>
          
          {/* Right Column */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-black font-bold">Upload Image</Label>
              <div className="w-full h-64 bg-gray-200 rounded-lg overflow-hidden flex items-center justify-center border border-gray-200">
                {/* Placeholder for uploaded image */}
                <span className="text-gray-400">Image Preview</span>
              </div>
              <div className="pt-2">
                <Button className="w-full bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold h-12">
                  Upload/Replace Image
                </Button>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Source</Label>
              <Input 
                placeholder="Enter source" 
                className="bg-white border-gray-200"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-black font-bold">Timestamp</Label>
              <Input 
                defaultValue="2023-10-05T10:30" 
                className="bg-white border-gray-200"
              />
            </div>
          </div>
        </div>
        
        {/* Bottom Actions */}
        <div className="mt-12 flex items-center justify-end gap-4 pt-6 border-t border-gray-100">
          <Link href="/dashboard/news">
            <Button variant="ghost" className="text-gray-600 hover:text-black font-medium">
              Cancel
            </Button>
          </Link>
          <Button variant="secondary" className="bg-gray-200 hover:bg-gray-300 text-gray-900 rounded-full px-6 font-medium">
            Save as Draft
          </Button>
          <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full px-8 font-bold">
            Publish
          </Button>
        </div>
      </div>
    </div>
  );
}