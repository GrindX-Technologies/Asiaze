"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import Link from "next/link";

const newsData = [
  {
    id: 1,
    headline: "Breaking: Major Event Unfolds",
    category: "Politics",
    language: "EN",
    status: "Draft",
    date: "12 Oct 2023",
  },
  {
    id: 2,
    headline: "Entertainment: Film Release",
    category: "Entertainment",
    language: "HIN",
    status: "Published",
    date: "10 Oct 2023",
  },
  {
    id: 3,
    headline: "Finance: Market Update",
    category: "Finance",
    language: "BEN",
    status: "Draft",
    date: "08 Oct 2023",
  },
];

export default function AllNewsListPage() {
  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <h2 className="text-2xl font-bold text-black tracking-tight">Manage News – All News</h2>
        
        <div className="flex items-center gap-3">
          <Link href="/dashboard/news/add">
            <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-medium px-6">
              + Add News
            </Button>
          </Link>
          
          <Input 
            placeholder="Search by headline or tags" 
            className="w-[250px] bg-white border-gray-200"
          />
          
          <Select>
            <SelectTrigger className="w-[120px] bg-white border-gray-200">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="politics">Politics</SelectItem>
              <SelectItem value="entertainment">Entertainment</SelectItem>
              <SelectItem value="finance">Finance</SelectItem>
            </SelectContent>
          </Select>
          
          <Select>
            <SelectTrigger className="w-[120px] bg-white border-gray-200">
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">EN</SelectItem>
              <SelectItem value="hin">HIN</SelectItem>
              <SelectItem value="ben">BEN</SelectItem>
            </SelectContent>
          </Select>
          
          <Select>
            <SelectTrigger className="w-[120px] bg-white border-gray-200">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="published">Published</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
        <Table>
          <TableHeader className="bg-[#E5E7EB]">
            <TableRow className="hover:bg-transparent">
              <TableHead className="w-[50px]"></TableHead>
              <TableHead className="font-bold text-black">Headline</TableHead>
              <TableHead className="font-bold text-black">Category</TableHead>
              <TableHead className="font-bold text-black">Language</TableHead>
              <TableHead className="font-bold text-black">Status</TableHead>
              <TableHead className="font-bold text-black">Date Created</TableHead>
              <TableHead className="font-bold text-black text-right pr-6">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {newsData.map((item) => (
              <TableRow key={item.id}>
                <TableCell>
                  <div className="w-4 h-4 rounded border border-gray-300 bg-gray-100"></div>
                </TableCell>
                <TableCell className="font-medium text-gray-900">{item.headline}</TableCell>
                <TableCell>
                  <Badge className="bg-[#E0202B] hover:bg-[#E0202B]/90 text-white border-none rounded-full px-3 font-normal">
                    {item.category}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-900">{item.language}</TableCell>
                <TableCell>
                  <Badge 
                    className={`text-white border-none rounded-full px-3 font-normal ${
                      item.status === 'Published' 
                        ? 'bg-green-500 hover:bg-green-600' 
                        : 'bg-[#E0202B] hover:bg-[#E0202B]/90'
                    }`}
                  >
                    {item.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-900 font-medium">{item.date}</TableCell>
                <TableCell className="text-right pr-6">
                  <div className="flex items-center justify-end gap-3 text-[#E0202B] text-sm font-medium">
                    <Link href={`/dashboard/news/edit/${item.id}`} className="hover:underline">Edit</Link>
                    <Link href="#" className="hover:underline">View</Link>
                    <Link href="#" className="hover:underline">Delete</Link>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}