"use client";

import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Pencil, Trash2 } from "lucide-react";
import { useState } from "react";

const initialCategories = [
  {
    id: 1,
    name: "Politics",
    labels: "English: Politics, Hindi: राजनीति, Bengali: রাজনীতি",
    status: "Active",
    visible: true,
  },
  {
    id: 2,
    name: "Sports",
    labels: "English: Sports, Hindi: खेल, Bengali: ক্রীড়া",
    status: "Inactive",
    visible: false,
  },
  {
    id: 3,
    name: "Business",
    labels: "English: Business, Hindi: व्यापार, Bengali: ব্যবসা",
    status: "Active",
    visible: true,
  },
];

export default function CategoriesPage() {
  const [categories, setCategories] = useState(initialCategories);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<typeof initialCategories[0] | null>(null);

  const toggleVisibility = (id: number) => {
    setCategories(categories.map(cat => 
      cat.id === id ? { ...cat, visible: !cat.visible } : cat
    ));
  };

  const openEditModal = (cat: typeof initialCategories[0]) => {
    setEditingCategory(cat);
    setIsEditModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-black tracking-tight">Manage Categories</h2>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6">
              + Add Category
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px] p-6 bg-white rounded-xl shadow-lg border-0">
            <DialogHeader className="mb-4">
              <DialogTitle className="text-xl font-bold text-black">Add New Category</DialogTitle>
            </DialogHeader>
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-black font-bold">Category Name</Label>
                <Input
                  id="name"
                  placeholder="Enter category name"
                  className="bg-white border-gray-200"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="labels" className="text-black font-bold">Language Labels</Label>
                <Input
                  id="labels"
                  placeholder="Enter language labels"
                  className="bg-white border-gray-200"
                />
              </div>
              <div className="flex justify-end pt-2">
                <Button 
                  className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6"
                  onClick={() => setIsAddModalOpen(false)}
                >
                  Add Category
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Edit Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[425px] p-6 bg-white rounded-xl shadow-lg border-0">
          <DialogHeader className="mb-4">
            <DialogTitle className="text-xl font-bold text-black">Edit Category</DialogTitle>
          </DialogHeader>
          {editingCategory && (
            <div className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="edit-name" className="text-black font-bold">Category Name</Label>
                <Input
                  id="edit-name"
                  defaultValue={editingCategory.name}
                  className="bg-white border-gray-200"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-labels" className="text-black font-bold">Language Labels</Label>
                <Input
                  id="edit-labels"
                  defaultValue={editingCategory.labels}
                  className="bg-white border-gray-200"
                />
              </div>
              <div className="flex justify-end pt-2">
                <Button 
                  className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Save Changes
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Table */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden">
        <Table>
          <TableHeader className="bg-[#F9FAFB]">
            <TableRow className="hover:bg-transparent">
              <TableHead className="font-bold text-black py-4">Category Name</TableHead>
              <TableHead className="font-bold text-black">Language Labels</TableHead>
              <TableHead className="font-bold text-black">Status</TableHead>
              <TableHead className="font-bold text-black text-center">Visibility</TableHead>
              <TableHead className="font-bold text-black text-right pr-6">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {categories.map((cat) => (
              <TableRow key={cat.id}>
                <TableCell className="font-medium text-gray-900 py-4">{cat.name}</TableCell>
                <TableCell className="text-gray-900">{cat.labels}</TableCell>
                <TableCell>
                  <Badge 
                    className={`text-white border-none rounded-full px-4 py-1 font-normal ${
                      cat.status === 'Active' 
                        ? 'bg-[#22C55E] hover:bg-[#22C55E]/90' 
                        : 'bg-[#9CA3AF] hover:bg-[#9CA3AF]/90'
                    }`}
                  >
                    {cat.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-center">
                  <Switch 
                    checked={cat.visible} 
                    onCheckedChange={() => toggleVisibility(cat.id)}
                    className={cat.visible ? "data-[state=checked]:bg-[#E0202B]" : ""}
                  />
                </TableCell>
                <TableCell className="text-right pr-6">
                  <div className="flex items-center justify-end gap-4 text-gray-700">
                    <Pencil 
                      className="w-4 h-4 cursor-pointer hover:text-black transition-colors" 
                      onClick={() => openEditModal(cat)}
                    />
                    <Trash2 className="w-4 h-4 cursor-pointer hover:text-black transition-colors" />
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}