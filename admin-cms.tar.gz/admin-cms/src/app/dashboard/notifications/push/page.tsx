"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

const pastNotificationsData = [
  {
    id: 1,
    title: "New Update Released",
    audience: "All Users",
    status: "Sent",
    date: "2023-10-25 14:30",
  },
  {
    id: 2,
    title: "Election Updates",
    audience: "Politics",
    status: "Scheduled",
    date: "2023-10-26 09:00",
  },
  {
    id: 3,
    title: "Sports Highlights",
    audience: "Sports",
    status: "Draft",
    date: "2023-10-24 17:00",
  },
  {
    id: 4,
    title: "Tech News",
    audience: "Technology",
    status: "Sent",
    date: "2023-10-23 11:45",
  },
  {
    id: 5,
    title: "Finance Tips",
    audience: "Finance",
    status: "Sent",
    date: "2023-10-22 08:20",
  },
];

export default function PushNotificationsPage() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      
      {/* Left Column: Send Notification Form */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        <h2 className="text-2xl font-bold text-black mb-6">Send Notification</h2>
        
        <div className="space-y-6">
          <Input 
            placeholder="Title" 
            className="bg-white border-gray-200 h-12"
          />

          <div className="relative">
            <Textarea 
              placeholder="Message Body (max 200 chars)" 
              className="bg-white border-gray-200 min-h-[120px] resize-none pb-8"
            />
            <span className="absolute bottom-3 right-3 text-xs text-gray-400">
              0/200
            </span>
          </div>

          <Input 
            placeholder="Link (optional)" 
            className="bg-white border-gray-200 h-12"
          />

          <div className="space-y-4 pt-2">
            <h3 className="font-bold text-black text-base">Audience Selector</h3>
            <RadioGroup defaultValue="all" className="space-y-3">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="all" id="all" className="border-gray-300 text-[#E0202B] focus:ring-[#E0202B]" />
                <Label htmlFor="all" className="text-gray-900 text-base font-normal">All Users</Label>
              </div>
              
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="category" id="category" className="border-gray-300 text-[#E0202B] focus:ring-[#E0202B]" />
                <Label htmlFor="category" className="text-gray-900 text-base font-normal w-24">By Category</Label>
                <Select disabled>
                  <SelectTrigger className="w-full bg-white border-gray-200 h-10 opacity-50">
                    <SelectValue placeholder="Politics" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="politics">Politics</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-3">
                <RadioGroupItem value="language" id="language" className="border-gray-300 text-[#E0202B] focus:ring-[#E0202B]" />
                <Label htmlFor="language" className="text-gray-900 text-base font-normal w-24">By Language</Label>
                <Select disabled>
                  <SelectTrigger className="w-full bg-white border-gray-200 h-10 opacity-50">
                    <SelectValue placeholder="EN" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">EN</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-4 pt-4 border-t border-gray-100">
            <RadioGroup defaultValue="now" className="flex items-center gap-6">
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="now" id="now" className="border-gray-300 text-[#E0202B] focus:ring-[#E0202B]" />
                <Label htmlFor="now" className="text-gray-900 text-base font-normal">Send Now</Label>
              </div>
              <div className="flex items-center space-x-3">
                <RadioGroupItem value="later" id="later" className="border-gray-300 text-[#E0202B] focus:ring-[#E0202B]" />
                <Label htmlFor="later" className="text-gray-900 text-base font-normal">Schedule for Later</Label>
              </div>
            </RadioGroup>
            
            <Input 
              type="datetime-local"
              className="bg-white border-gray-200 h-12"
              disabled
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-8">
              Send Notification
            </Button>
            <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-gray-900 border-0 rounded-full font-bold px-8">
              Save as Draft
            </Button>
          </div>
        </div>
      </div>

      {/* Right Column: Past Notifications Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        <h2 className="text-2xl font-bold text-black mb-6">Past Notifications</h2>
        
        <div className="rounded-lg border border-gray-200 overflow-hidden">
          <Table>
            <TableHeader className="bg-gray-50">
              <TableRow className="border-b border-gray-200 hover:bg-transparent">
                <TableHead className="font-bold text-black py-3">Title</TableHead>
                <TableHead className="font-bold text-black">Audience</TableHead>
                <TableHead className="font-bold text-black">Status</TableHead>
                <TableHead className="font-bold text-black">Date & Time</TableHead>
                <TableHead className="font-bold text-black">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pastNotificationsData.map((item) => (
                <TableRow key={item.id} className="border-b border-gray-200 hover:bg-gray-50/50">
                  <TableCell className="py-4 text-gray-900 font-medium">
                    {item.title}
                  </TableCell>
                  <TableCell className="text-gray-600">
                    {item.audience}
                  </TableCell>
                  <TableCell className="text-gray-600">
                    {item.status}
                  </TableCell>
                  <TableCell className="text-gray-600">
                    {item.date}
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1 text-sm">
                      <button className="text-[#3b82f6] hover:underline text-left">View</button>
                      <button className="text-[#3b82f6] hover:underline text-left">Resend</button>
                      <button className="text-[#E0202B] hover:underline text-left">Delete</button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

    </div>
  );
}
