"use client";

import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Eye, RefreshCw, Trash2 } from "lucide-react";

const detailedPastNotificationsData = [
  {
    id: 1,
    title: "Notification Title 1",
    audience: "All Users",
    status: "Sent",
    date: "2023-10-01 10:00 AM",
    sentBy: "admin123",
  },
  {
    id: 2,
    title: "Notification Title 2",
    audience: "Category Name",
    status: "Scheduled",
    date: "2023-10-02 11:00 AM",
    sentBy: "admin456",
  },
  {
    id: 3,
    title: "Notification Title 3",
    audience: "Language",
    status: "Draft",
    date: "2023-10-03 12:00 PM",
    sentBy: "admin789",
  },
];

export default function PastNotificationsPage() {
  return (
    <div className="space-y-6">
      
      {/* Header & Filters */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <h2 className="text-3xl font-bold text-black tracking-tight">Past Notifications</h2>
        
        <div className="flex flex-col sm:flex-row gap-4">
          <Input 
            placeholder="Search notifications by title..." 
            className="w-full sm:w-[300px] bg-white border-gray-200 h-11"
          />
          
          <Select>
            <SelectTrigger className="w-[140px] bg-white border-gray-200 h-11">
              <SelectValue placeholder="Audience: All" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Audience: All</SelectItem>
              <SelectItem value="category">Category</SelectItem>
              <SelectItem value="language">Language</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-[130px] bg-white border-gray-200 h-11">
              <SelectValue placeholder="Status: Sent" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sent">Status: Sent</SelectItem>
              <SelectItem value="scheduled">Scheduled</SelectItem>
              <SelectItem value="draft">Draft</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-[130px] bg-white border-gray-200 h-11">
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="all">All Time</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <Table>
          <TableHeader className="bg-[#F9FAFB]">
            <TableRow className="hover:bg-transparent border-b border-gray-100">
              <TableHead className="font-bold text-black py-4 px-6">Title</TableHead>
              <TableHead className="font-bold text-black">Audience</TableHead>
              <TableHead className="font-bold text-black">Status</TableHead>
              <TableHead className="font-bold text-black">Date & Time</TableHead>
              <TableHead className="font-bold text-black">Sent By</TableHead>
              <TableHead className="font-bold text-black pr-6">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {detailedPastNotificationsData.map((item) => (
              <TableRow key={item.id} className="border-b border-gray-50">
                <TableCell className="py-4 px-6 text-gray-900 font-medium">
                  {item.title}
                </TableCell>
                <TableCell className="text-gray-900">
                  {item.audience}
                </TableCell>
                <TableCell>
                  <Badge 
                    className={`text-white border-none rounded-full px-3 py-0.5 font-medium ${
                      item.status === 'Sent' 
                        ? 'bg-[#22C55E] hover:bg-[#22C55E]/90' 
                        : item.status === 'Draft' ? 'bg-[#E0202B] hover:bg-[#C11B24]'
                        : 'bg-[#424242] hover:bg-[#424242]/90'
                    }`}
                  >
                    {item.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-900">{item.date}</TableCell>
                <TableCell className="text-gray-900">{item.sentBy}</TableCell>
                <TableCell className="pr-6">
                  <div className="flex items-center gap-2">
                    <div className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full cursor-pointer transition-colors">
                      <Eye className="w-4 h-4 text-white fill-current" />
                    </div>
                    <div className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full cursor-pointer transition-colors">
                      <RefreshCw className="w-4 h-4 text-white" />
                    </div>
                    <div className="bg-gray-200 hover:bg-gray-300 p-2 rounded-full cursor-pointer transition-colors">
                      <Trash2 className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

    </div>
  );
}
