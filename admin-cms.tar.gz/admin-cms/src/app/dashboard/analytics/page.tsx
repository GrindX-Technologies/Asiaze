"use client";

import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, UserCheck, FileText, Film } from "lucide-react";
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Legend
} from "recharts";

// Dummy Data
const userGrowthData = [
  { name: 'Mon', new: 400, returning: 240 },
  { name: 'Tue', new: 300, returning: 139 },
  { name: 'Wed', new: 200, returning: 980 },
  { name: 'Thu', new: 278, returning: 390 },
  { name: 'Fri', new: 189, returning: 480 },
  { name: 'Sat', new: 239, returning: 380 },
  { name: 'Sun', new: 349, returning: 430 },
];

const engagementData = [
  { name: 'Articles', views: 4000, interactions: 2400 },
  { name: 'Reels', views: 3000, interactions: 1398 },
  { name: 'Stories', views: 2000, interactions: 9800 },
];

const categoryData = [
  { name: 'Politics', value: 400 },
  { name: 'Finance', value: 300 },
  { name: 'Entertainment', value: 300 },
  { name: 'Sports', value: 200 },
];
const COLORS = ['#E0202B', '#9ca3af', '#6b7280', '#d1d5db'];

const languageData = [
  { name: 'EN', articles: 4000, reels: 2400 },
  { name: 'HIN', articles: 3000, reels: 1398 },
  { name: 'BEN', articles: 2000, reels: 9800 },
];

export default function AnalyticsPage() {
  return (
    <div className="space-y-8">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-black tracking-tight">Analytics & Reports</h2>
        <Select defaultValue="today">
          <SelectTrigger className="w-[120px] bg-white border-gray-200">
            <SelectValue placeholder="Today" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="week">This Week</SelectItem>
            <SelectItem value="month">This Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="p-3 bg-red-50 rounded-lg">
            <Users className="w-6 h-6 text-[#E0202B]" />
          </div>
          <div>
            <p className="text-sm font-bold text-black mb-1">Total</p>
            <h3 className="text-2xl font-bold text-black">1,234</h3>
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="p-3 bg-red-50 rounded-lg">
            <UserCheck className="w-6 h-6 text-[#E0202B]" />
          </div>
          <div>
            <p className="text-sm font-bold text-black mb-1">Active Users</p>
            <h3 className="text-2xl font-bold text-black">567</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="p-3 bg-red-50 rounded-lg">
            <FileText className="w-6 h-6 text-[#E0202B]" />
          </div>
          <div>
            <p className="text-sm font-bold text-black mb-1">Total Articles</p>
            <h3 className="text-2xl font-bold text-black">89</h3>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center gap-4">
          <div className="p-3 bg-red-50 rounded-lg">
            <Film className="w-6 h-6 text-[#E0202B]" />
          </div>
          <div>
            <p className="text-sm font-bold text-black mb-1">Total Reels</p>
            <h3 className="text-2xl font-bold text-black">45</h3>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Line Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-black mb-6">User Growth</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={userGrowthData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <Tooltip />
                <Line type="monotone" dataKey="new" stroke="#9ca3af" strokeWidth={3} dot={false} />
                <Line type="monotone" dataKey="returning" stroke="#E0202B" strokeWidth={3} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Engagement Stacked Bar Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-black mb-6">Engagement by Content Type</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={engagementData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f3f4f6" />
                <XAxis type="number" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <Tooltip />
                <Bar dataKey="views" stackId="a" fill="#9ca3af" radius={[0, 0, 0, 0]} barSize={32} />
                <Bar dataKey="interactions" stackId="a" fill="#E0202B" radius={[0, 4, 4, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Performance Donut Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-black mb-6">Category Performance</h3>
          <div className="h-[300px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={categoryData}
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={2}
                  dataKey="value"
                  stroke="none"
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Language Distribution Bar Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-black mb-6">Language Distribution</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={languageData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f3f4f6" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#6b7280', fontSize: 12}} />
                <Tooltip />
                <Bar dataKey="articles" fill="#9ca3af" radius={[4, 4, 0, 0]} barSize={32} />
                <Bar dataKey="reels" fill="#E0202B" radius={[4, 4, 0, 0]} barSize={32} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Top 10 Articles Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-black mb-6">Top 10 Articles</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="pb-4 font-bold text-black">Title</th>
                <th className="pb-4 font-bold text-black">Views</th>
                <th className="pb-4 font-bold text-black">Likes</th>
                <th className="pb-4 font-bold text-black">Shares</th>
              </tr>
            </thead>
            <tbody className="text-gray-900">
              <tr className="border-b border-gray-50">
                <td className="py-4">Breaking News</td>
                <td className="py-4">1,234</td>
                <td className="py-4">567</td>
                <td className="py-4">98</td>
              </tr>
              <tr className="border-b border-gray-50">
                <td className="py-4">Tech Innovations</td>
                <td className="py-4">1,000</td>
                <td className="py-4">450</td>
                <td className="py-4">123</td>
              </tr>
              <tr>
                <td className="py-4">Market Updates</td>
                <td className="py-4">950</td>
                <td className="py-4">400</td>
                <td className="py-4">110</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Top 10 Reels Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-bold text-black mb-6">Top 10 Reels</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="pb-4 font-bold text-black">Title</th>
                <th className="pb-4 font-bold text-black">Views</th>
                <th className="pb-4 font-bold text-black">Likes</th>
                <th className="pb-4 font-bold text-black">Comments</th>
              </tr>
            </thead>
            <tbody className="text-gray-900">
              <tr className="border-b border-gray-50">
                <td className="py-4">Viral Dance</td>
                <td className="py-4">5,678</td>
                <td className="py-4">2,345</td>
                <td className="py-4">1,234</td>
              </tr>
              <tr className="border-b border-gray-50">
                <td className="py-4">Funny Pets</td>
                <td className="py-4">4,500</td>
                <td className="py-4">2,100</td>
                <td className="py-4">1,000</td>
              </tr>
              <tr>
                <td className="py-4">Cooking Hacks</td>
                <td className="py-4">4,000</td>
                <td className="py-4">1,800</td>
                <td className="py-4">900</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="flex justify-end gap-4 pt-4">
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-8">
          Export as PDF
        </Button>
        <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-gray-900 border-0 rounded-full font-bold px-8">
          Export as CSV
        </Button>
      </div>

    </div>
  );
}
