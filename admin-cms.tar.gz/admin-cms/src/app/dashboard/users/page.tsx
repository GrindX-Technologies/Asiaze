"use client";

import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Pencil, Eye, Trash2, Ban, CheckCircle2 } from "lucide-react";
import Link from "next/link";
import { Checkbox } from "@/components/ui/checkbox";

const usersData = [
  {
    id: 1,
    name: "Alice Johnson",
    emailPhone: "alice.j@example.com / +1234567890",
    role: "Admin",
    status: "Active",
    date: "2023-05-12",
  },
  {
    id: 2,
    name: "Robert Smith",
    emailPhone: "robert.smith@email.com / +1234567890",
    role: "User",
    status: "Active",
    date: "2023-04-15",
  },
  {
    id: 3,
    name: "John Smith",
    emailPhone: "john.smith@email.com / +1987654321",
    role: "Moderator",
    status: "Blocked",
    date: "2023-04-25",
  },
  {
    id: 4,
    name: "Samantha Green",
    emailPhone: "samantha.green@email.com / +1123456789",
    role: "User",
    status: "Inactive",
    date: "2023-03-15",
  },
  {
    id: 5,
    name: "Emily Brown",
    emailPhone: "emily.brown@email.com / +1987654321",
    role: "User",
    status: "Active",
    date: "2022-11-22",
  },
];

export default function UsersListPage() {
  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-black tracking-tight">Manage Users</h2>
        <Link href="#">
          <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6 py-2 h-auto">
            + Add User
          </Button>
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <Input 
            placeholder="Search by name, email, or phone..." 
            className="w-full bg-white border-gray-200 h-11"
          />
        </div>
        <div className="flex gap-4">
          <Select>
            <SelectTrigger className="w-[160px] bg-white border-gray-200 h-11">
              <SelectValue placeholder="User Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin">Admin</SelectItem>
              <SelectItem value="moderator">Moderator</SelectItem>
              <SelectItem value="user">User</SelectItem>
            </SelectContent>
          </Select>

          <Select>
            <SelectTrigger className="w-[140px] bg-white border-gray-200 h-11">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="blocked">Blocked</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <Table>
          <TableHeader className="bg-[#F9FAFB]">
            <TableRow className="hover:bg-transparent border-b border-gray-100">
              <TableHead className="w-[40px] py-4">
                <Checkbox className="ml-4 border-gray-300" />
              </TableHead>
              <TableHead className="font-bold text-black py-4">Name</TableHead>
              <TableHead className="font-bold text-black">Email/Phone</TableHead>
              <TableHead className="font-bold text-black">Role</TableHead>
              <TableHead className="font-bold text-black">Status</TableHead>
              <TableHead className="font-bold text-black">Date Registered</TableHead>
              <TableHead className="font-bold text-black text-right pr-8">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {usersData.map((item) => (
              <TableRow key={item.id} className="border-b border-gray-50">
                <TableCell className="py-4">
                  <Checkbox className="ml-4 border-gray-300" />
                </TableCell>
                <TableCell className="text-gray-900 font-medium">
                  {item.name}
                </TableCell>
                <TableCell className="text-gray-600">
                  {item.emailPhone}
                </TableCell>
                <TableCell>
                  <Badge 
                    className={`text-white border-none rounded-full px-3 py-0.5 font-medium ${
                      item.role === 'Admin' || item.id === 4 || item.id === 5
                        ? 'bg-[#E0202B] hover:bg-[#C11B24]' 
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    }`}
                  >
                    {item.role}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge 
                    className={`text-white border-none rounded-full px-3 py-0.5 font-medium ${
                      item.status === 'Active' 
                        ? 'bg-[#22C55E] hover:bg-[#22C55E]/90' 
                        : 'bg-[#9CA3AF] hover:bg-[#9CA3AF]/90'
                    }`}
                  >
                    {item.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-gray-900 font-medium">{item.date}</TableCell>
                <TableCell className="text-right pr-8">
                  <div className="flex items-center justify-end gap-3 text-gray-700">
                    <Link href={`#`}>
                      <Eye className="w-[18px] h-[18px] cursor-pointer hover:text-black transition-colors" />
                    </Link>
                    <Link href={`/dashboard/users/edit/${item.id}`}>
                      <Pencil className="w-[18px] h-[18px] cursor-pointer hover:text-black transition-colors" />
                    </Link>
                    {item.status === 'Blocked' ? (
                       <CheckCircle2 className="w-[18px] h-[18px] cursor-pointer hover:text-green-600 text-gray-700 transition-colors" />
                    ) : (
                      <Ban className="w-[18px] h-[18px] cursor-pointer hover:text-red-600 text-gray-700 transition-colors" />
                    )}
                    <Trash2 className="w-[18px] h-[18px] cursor-pointer hover:text-red-600 text-[#E0202B] transition-colors" />
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Footer Bulk Actions */}
      <div className="flex flex-wrap gap-3 pt-4">
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6">
          Block Users
        </Button>
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6">
          Unblock Users
        </Button>
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6">
          Delete Users
        </Button>
        <Button className="bg-[#22C55E] hover:bg-[#16a34a] text-white rounded-full font-bold px-6">
          USER EXPORT
        </Button>
      </div>
    </div>
  );
}
