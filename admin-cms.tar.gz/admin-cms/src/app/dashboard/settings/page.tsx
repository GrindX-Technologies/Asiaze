"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState("general");

  return (
    <div className="space-y-6 max-w-[1000px]">
      <h2 className="text-3xl font-bold text-black tracking-tight">Settings</h2>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
        
        {/* Custom Tabs */}
        <div className="flex flex-wrap gap-3 mb-10">
          <Button 
            variant="outline" 
            className={`rounded-full px-6 font-medium ${activeTab === 'general' ? 'bg-gray-100 border-gray-200 text-black shadow-sm' : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'}`}
            onClick={() => setActiveTab('general')}
          >
            General Settings
          </Button>
          <Button 
            variant="outline" 
            className={`rounded-full px-6 font-medium ${activeTab === 'language' ? 'bg-gray-100 border-gray-200 text-black shadow-sm' : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'}`}
            onClick={() => setActiveTab('language')}
          >
            Language Settings
          </Button>
          <Button 
            variant="outline" 
            className={`rounded-full px-6 font-medium ${activeTab === 'policies' ? 'bg-gray-100 border-gray-200 text-black shadow-sm' : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'}`}
            onClick={() => setActiveTab('policies')}
          >
            Policies & Static Pages
          </Button>
          <Button 
            variant="outline" 
            className={`rounded-full px-6 font-medium ${activeTab === 'admin' ? 'bg-gray-100 border-gray-200 text-black shadow-sm' : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'}`}
            onClick={() => setActiveTab('admin')}
          >
            Admin Users Management
          </Button>
          <Button 
            variant="outline" 
            className={`rounded-full px-6 font-medium ${activeTab === 'notifications' ? 'bg-gray-100 border-gray-200 text-black shadow-sm' : 'bg-gray-50 border-transparent text-gray-600 hover:bg-gray-100'}`}
            onClick={() => setActiveTab('notifications')}
          >
            Notifications Defaults
          </Button>
        </div>

        <div className="space-y-10">
          
          {/* General Settings */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Site/App Name</Label>
              <Input className="bg-white border-gray-200 h-12" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Logo Upload</Label>
              <Input className="bg-white border-gray-200 h-12" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Contact Email</Label>
              <Input className="bg-white border-gray-200 h-12" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Footer Text</Label>
              <Textarea className="bg-white border-gray-200 min-h-[120px] resize-none" />
            </div>
          </div>

          {/* Language Settings */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Default Language</Label>
              <Select defaultValue="en">
                <SelectTrigger className="bg-white border-gray-200 h-12 text-gray-500">
                  <SelectValue placeholder="EN" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">EN</SelectItem>
                  <SelectItem value="es">ES</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium block mb-3">Enable/Disable Language</Label>
              <Switch className="data-[state=unchecked]:bg-[#E0202B]" />
            </div>
          </div>

          {/* Policies & Static Pages */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Privacy Policy</Label>
              <Textarea className="bg-white border-gray-200 min-h-[160px] resize-none" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Terms & Conditions</Label>
              <Textarea className="bg-white border-gray-200 min-h-[160px] resize-none" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">About Us</Label>
              <Textarea className="bg-white border-gray-200 min-h-[160px] resize-none" />
            </div>
          </div>

          {/* Admin Users Management */}
          <div className="space-y-4">
            <h3 className="font-bold text-black text-sm">Admin Users Management</h3>
            <div className="border border-gray-100 rounded-xl overflow-hidden">
              <Table>
                <TableHeader className="bg-white">
                  <TableRow className="border-b border-gray-100 hover:bg-transparent">
                    <TableHead className="font-bold text-black py-4 px-6">Name</TableHead>
                    <TableHead className="font-bold text-black">Email</TableHead>
                    <TableHead className="font-bold text-black">Role</TableHead>
                    <TableHead className="font-bold text-black">Status</TableHead>
                    <TableHead className="text-right pr-6">
                      <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-6 h-9">
                        Add New Admin
                      </Button>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="border-b border-gray-50 hover:bg-transparent">
                    <TableCell className="py-5 px-6 text-gray-900 font-medium">John Doe</TableCell>
                    <TableCell className="text-gray-900">john@example.com</TableCell>
                    <TableCell className="text-gray-900">Super Admin</TableCell>
                    <TableCell className="text-gray-900">Active</TableCell>
                    <TableCell className="text-right pr-6">
                      <div className="flex justify-end gap-2">
                        <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-black border-0 rounded-full h-8 px-4 font-medium">
                          Edit
                        </Button>
                        <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-black border-0 rounded-full h-8 px-4 font-medium">
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
            </div>
          </div>

          {/* Notifications Defaults */}
          <div className="space-y-6">
            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Default Notification Tone</Label>
              <Input className="bg-white border-gray-200 h-12" />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-medium">Default Delivery Type</Label>
              <Select defaultValue="immediate">
                <SelectTrigger className="bg-white border-gray-200 h-12 text-gray-400">
                  <SelectValue placeholder="Immediate" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="immediate">Immediate</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

        </div>
      </div>

      {/* Footer Actions */}
      <div className="flex justify-end gap-4 pt-4 pb-12">
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-8">
          Save Changes
        </Button>
        <Button variant="outline" className="bg-gray-100 hover:bg-gray-200 text-gray-900 border-0 rounded-full font-bold px-8">
          Cancel
        </Button>
      </div>

    </div>
  );
}
