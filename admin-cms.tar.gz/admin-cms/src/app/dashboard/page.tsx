"use client";

import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
} from "recharts";

const lineChartData = [
  { name: "1", current: 40, previous: 24 },
  { name: "2", current: 30, previous: 13 },
  { name: "3", current: 20, previous: 98 },
  { name: "4", current: 27, previous: 39 },
  { name: "5", current: 18, previous: 48 },
  { name: "6", current: 23, previous: 38 },
  { name: "7", current: 34, previous: 43 },
];

const barChartData = [
  { name: "Mon", articles: 40, videos: 24 },
  { name: "Tue", articles: 30, videos: 13 },
  { name: "Wed", articles: 20, videos: 98 },
  { name: "Thu", articles: 27, videos: 39 },
  { name: "Fri", articles: 18, videos: 48 },
  { name: "Sat", articles: 23, videos: 38 },
  { name: "Sun", articles: 34, videos: 43 },
];

export default function DashboardPage() {
  const [stats, setStats] = useState({ users: 0, articles: 0, reels: 0 });
  const [latestNews, setLatestNews] = useState<any[]>([]);
  const [latestReels, setLatestReels] = useState<any[]>([]);

  useEffect(() => {
    // Fetch stats and lists from the backend API
    const fetchData = async () => {
      try {
        const token = localStorage.getItem("token") || "";
        
        // Assuming we have these endpoints or fetching all and getting lengths
        const [newsRes, reelsRes, usersRes] = await Promise.all([
          fetch("/api/news", { headers: { Authorization: `Bearer ${token}` } }),
          fetch("/api/reels", { headers: { Authorization: `Bearer ${token}` } }),
          fetch("/api/users", { headers: { Authorization: `Bearer ${token}` } })
        ]);

        const news = newsRes.ok ? await newsRes.json() : [];
        const reels = reelsRes.ok ? await reelsRes.json() : [];
        const users = usersRes.ok ? await usersRes.json() : [];

        setStats({
          users: users.length || 0,
          articles: news.length || 0,
          reels: reels.length || 0
        });

        setLatestNews(news.slice(0, 5));
        setLatestReels(reels.slice(0, 5));
      } catch (err) {
        console.error("Error fetching dashboard data:", err);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-8">
      {/* Welcome Banner */}
      <Card className="border-none shadow-sm">
        <CardContent className="p-6">
          <h2 className="text-2xl font-bold text-[#E0202B]">
            Welcome Admin, here&apos;s today&apos;s overview
          </h2>
        </CardContent>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{stats.users}</div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Articles</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{stats.articles}</div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Reels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">{stats.reels}</div>
          </CardContent>
        </Card>
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Bookmarks/Shares</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-foreground">345</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader>
            <CardTitle className="text-base font-bold text-foreground">Daily Active Users</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={lineChartData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="name" axisLine={true} tickLine={false} tick={false} />
                  <YAxis hide={true} />
                  <Tooltip />
                  <Line type="monotone" dataKey="current" stroke="#E0202B" strokeWidth={3} dot={false} />
                  <Line type="monotone" dataKey="previous" stroke="#9CA3AF" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader>
            <CardTitle className="text-base font-bold text-foreground">Article/Video Engagement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={barChartData} margin={{ top: 5, right: 5, bottom: 5, left: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                  <XAxis dataKey="name" axisLine={true} tickLine={false} tick={false} />
                  <YAxis hide={true} />
                  <Tooltip />
                  <Bar dataKey="videos" stackId="a" fill="#9CA3AF" radius={[0, 0, 0, 0]} />
                  <Bar dataKey="articles" stackId="a" fill="#E0202B" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader>
            <CardTitle className="text-base font-bold text-foreground">Latest News Entries</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {latestNews.map((newsItem: any, i: number) => (
                <div key={newsItem._id || i} className="flex justify-between items-center py-2 border-b border-border last:border-0">
                  <span className="text-foreground text-sm">{newsItem.title || `News Title ${i + 1}`}</span>
                  <Link href={`/dashboard/news/edit/${newsItem._id || i}`} className="text-[#E0202B] text-sm font-medium hover:underline">
                    Edit
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm bg-card text-card-foreground">
          <CardHeader>
            <CardTitle className="text-base font-bold text-foreground">Latest Reels</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {latestReels.map((reelItem: any, i: number) => (
                <div key={reelItem._id || i} className="flex justify-between items-center py-2 border-b border-border last:border-0">
                  <span className="text-foreground text-sm">{reelItem.title || `Reel Title ${i + 1}`}</span>
                  <Link href={`/dashboard/reels/edit/${reelItem._id || i}`} className="text-[#E0202B] text-sm font-medium hover:underline">
                    Edit
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}