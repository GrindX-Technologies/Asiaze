"use client";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Upload } from "lucide-react";
import Image from "next/image";

export default function AddReelPage() {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 max-w-[1200px]">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-12 gap-y-8">
        
        {/* Left Column */}
        <div className="space-y-6">
          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Reel Title/Headline</Label>
            <Input 
              placeholder="Enter title" 
              className="bg-white border-gray-200 h-12"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Summary/Caption</Label>
            <Textarea 
              placeholder="Enter summary" 
              className="bg-white border-gray-200 min-h-[160px] resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Full Article Link</Label>
            <Input 
              placeholder="Enter URL" 
              className="bg-white border-gray-200 h-12"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Category</Label>
            <Select>
              <SelectTrigger className="bg-white border-gray-200 h-12">
                <SelectValue placeholder="Politics" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="politics">Politics</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="entertainment">Entertainment</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Language</Label>
            <Select>
              <SelectTrigger className="bg-white border-gray-200 h-12">
                <SelectValue placeholder="EN" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">EN</SelectItem>
                <SelectItem value="hin">HIN</SelectItem>
                <SelectItem value="ben">BEN</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Tags</Label>
            <div className="flex items-center gap-2 p-2 border border-gray-200 rounded-md bg-white min-h-[48px] flex-wrap">
              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                #Politics
              </span>
              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                #Finance
              </span>
              <span className="bg-gray-100 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                #Entertainment
              </span>
              <Input 
                className="border-0 shadow-none focus-visible:ring-0 flex-1 min-w-[120px] p-0 h-8"
              />
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-8">
          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Upload Video</Label>
            <div className="border-2 border-dashed border-gray-200 rounded-xl bg-gray-50 flex items-center justify-between overflow-hidden h-[180px]">
              <div className="flex-1 px-8 text-center sm:text-left">
                <p className="text-gray-500 font-medium">
                  Drag & drop video here or click to <br className="hidden sm:block" />
                  <span className="text-[#3b82f6] cursor-pointer hover:underline">browse</span>
                </p>
              </div>
              <div className="w-[200px] h-full bg-gray-200 relative">
                {/* Dummy video thumbnail placeholder matching the image */}
                <Image 
                  src="https://images.unsplash.com/photo-1542204165-65bf26472b9b?q=80&w=200&h=180&fit=crop"
                  alt="Video thumbnail"
                  fill
                  className="object-cover opacity-80"
                />
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-black font-bold text-base">Upload Thumbnail (Optional)</Label>
            <div className="border-2 border-dashed border-gray-200 rounded-xl bg-gray-50 flex flex-col items-center justify-center h-[120px] cursor-pointer hover:bg-gray-100 transition-colors">
              <Upload className="w-8 h-8 text-[#E0202B] mb-2" />
              <p className="text-gray-500 font-medium">Click to upload thumbnail</p>
            </div>
          </div>

          <div className="space-y-6 pt-4">
            <div className="flex items-center justify-between max-w-[300px]">
              <Label className="text-black font-bold text-base cursor-pointer" htmlFor="featured">Featured</Label>
              <Switch id="featured" defaultChecked className="data-[state=checked]:bg-[#E0202B]" />
            </div>
            
            <div className="flex items-center justify-between max-w-[300px]">
              <Label className="text-black font-bold text-base cursor-pointer" htmlFor="comments">Enable Comments</Label>
              <Switch id="comments" defaultChecked className="data-[state=checked]:bg-[#E0202B]" />
            </div>
          </div>
        </div>
      </div>

      {/* Footer Actions */}
      <div className="flex justify-end gap-4 mt-12 pt-8 border-t border-gray-100">
        <Button variant="outline" className="bg-gray-400/80 hover:bg-gray-400 text-white border-0 rounded-full font-bold px-8">
          Cancel
        </Button>
        <Button variant="outline" className="bg-gray-200 hover:bg-gray-300 text-gray-900 border-0 rounded-full font-bold px-8">
          Save Draft
        </Button>
        <Button className="bg-[#E0202B] hover:bg-[#C11B24] text-white rounded-full font-bold px-8">
          Publish
        </Button>
      </div>
    </div>
  );
}
